const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const HelloWorldPlugin = require('./src/plugins/hello-world');
const MyPlugin = require('./src/plugins/auto-comment');

module.exports = {
  entry: path.join(__dirname, './src/index.js'),
  output: {
    path: path.join(__dirname, 'dist'),
    filename: 'bundle.js',
  },
  module: {
    rules: [{
      test: /\.pug$/,
      use: [
        "html-loader",
        {
          loader: "pug-loader",
          options: {
            data: {
              asdfasfd: "1"
            }
          }
        }
      ]
    }]
  },
  resolveLoader: {
    modules: [path.join(__dirname, './src/loaders'), 'node_modules'],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./src/index.pug"
    }),
    new HelloWorldPlugin(),
    new MyPlugin(),
  ]
}