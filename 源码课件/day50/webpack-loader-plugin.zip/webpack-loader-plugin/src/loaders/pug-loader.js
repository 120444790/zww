const pug = require('pug');
const loaderUtils = require('loader-utils');
module.exports = function(source) {
  if (this.cacheable) this.cacheable();
  const options = loaderUtils.getOptions(this);
  console.log('-------options', options);
  return pug.render(source);
}