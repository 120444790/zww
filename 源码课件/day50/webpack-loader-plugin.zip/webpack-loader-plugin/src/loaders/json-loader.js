module.exports = function(source) {
  var value = typeof source === 'string' ? JSON.parse(source): source;
  return `module.exports = ${JSON.stringify(value)}`;
}