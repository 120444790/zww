class MyPlugin {
  apply(compiler) {
    compiler.plugin("emit", (compilation, callback) => {
      compilation.chunks.forEach(chunk => {
        chunk.files.forEach(filename => {
          var source = compilation.assets[filename].source();
          compilation.assets[filename].source = function() {
            return `/* auto comment */ ${source}`;
          }
        });
        callback();
      });
    });
  }
}

module.exports = MyPlugin;