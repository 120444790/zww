function HelloWorld() {

}

HelloWorld.prototype.apply = function(compiler) {
  compiler.plugin("done", function() {
    console.log("hello world");
  });
}

module.exports = HelloWorld;