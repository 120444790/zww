
module.exports = function() {
    console.log('new Date');
}