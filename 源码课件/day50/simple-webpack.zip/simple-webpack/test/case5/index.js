const a = require('./a');
const b = require('./b');

a();
b();