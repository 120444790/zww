module.exports = function() {
    console.log('123123123');
}