const func = require('./a');
func();
func();