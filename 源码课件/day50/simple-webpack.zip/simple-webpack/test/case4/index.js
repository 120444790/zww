setTimeout(() => {
    require.ensure('./a')
        .then(module => {
            console.log(module);
        });
}, 2000);
