__dynamicRequire("chunk_0", function (require, module, exports) {
module.exports = new Date().getTime();
});