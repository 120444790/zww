module.exports = [
    {
        base: './test/case1',
        name: "hello"
    },
    {
        base: './test/case2',
        name: "case2"
    },
    {
        base: './test/case3'
    },
    {
        base: './test/case4'
    },
    {
        base: './test/case5'
    }
]