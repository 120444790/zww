declare var window: Window;

interface Window {
  PR: {
    prettyPrint(): void
  }
}