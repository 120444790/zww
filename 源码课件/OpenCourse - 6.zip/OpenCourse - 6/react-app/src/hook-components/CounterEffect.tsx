import React, { useState, useEffect } from "react";

export function CounterEffect() {
    const [count, setCount] = useState(0);

    useEffect(() => {
        console.log(count);
    }, [count]);

    const onClick = () => {
        setCount(count + 1);
    };

    return (
        <div>
            <div>{count}</div>
            <button onClick={onClick}>点击</button>
        </div>
    );
}
