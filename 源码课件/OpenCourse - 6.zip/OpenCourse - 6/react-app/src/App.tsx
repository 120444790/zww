import React from "react";
import logo from "./logo.svg";
import "./App.css";
// import ByeWorld from "./components/low/ByeWorld";
// import HelloWorld from "./components/low/HelloWorld";

// import ByeWorld from "./components/high/ByeWorld";
// import HelloWorld from "./components/high/HelloWorld";

// import ByeWorld from "./components/high-decorator/ByeWorld";
// import HelloWorld from "./components/high-decorator/HelloWorld";

// import ByeWorld from "./components/multi-high-decorator/ByeWorld";
// import HelloWorld from "./components/multi-high-decorator/HelloWorld";

// import RefComponent from "./components/ref/index";

// import HijackComponent from "./components/hijack/index";
// import { Counter } from "./hook-components/Counter";
// import { CounterEffect } from "./hook-components/CounterEffect";
// import Counter2 from "./execrise/useMemo";

import provider, { useCustomRedux } from "./redux/index";
import { reducer, initialState, Reducer1Actions } from "./redux/reducers";
import { Parent } from "./execrise/useRef";
import { ExecriseUseEffectCounter } from "./execrise/useEffect";
import ExecriseUseMemoCounter from "./execrise/useMemo";

localStorage.setItem("myName", "qiuku");

// function Button() {
//     const { state, dispatch } = useCustomRedux<
//         typeof initialState,
//         Reducer1Actions
//     >();

//     return (
//         <button onClick={() => dispatch({ type: "ADD_COUNTER" })}>
//             触发dispatch-action
//         </button>
//     );
// }

function App() {
    // const { state, dispatch } = useCustomRedux<
    //     typeof initialState,
    //     Reducer1Actions
    // >();

    return (
        <div className="App">
            <header className="App-header">
                {/* <HelloWorld />
                <br />
                <ByeWorld /> */}
                {/* <RefComponent name="哈哈哈哈" /> */}
                {/* <HijackComponent /> */}
                {/* <Counter /> */}
                {/* <CounterEffect /> */}
                {/* <Counter2 /> */}
                {/* <div>
                    <h2>{state.reducer1.count}</h2>
                    <Button />
                </div> */}
                {/* <Parent /> */}
                {/* <ExecriseUseEffectCounter /> */}
                <ExecriseUseMemoCounter />
            </header>
        </div>
    );
}

// export default provider(reducer, initialState)(App);
export default App;
