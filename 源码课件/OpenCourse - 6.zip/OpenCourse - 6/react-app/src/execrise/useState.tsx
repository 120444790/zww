// React 假设当你多次调用 useState 的时候，你能保证每次渲染时它们的调用顺序是不变的。
// 通过在函数组件里调用它来给组件添加一些内部 state，React会 在重复渲染时保留这个 state
// useState 唯一的参数就是初始 state
// useState 会返回一个数组：一个 state，一个更新 state 的函数

// 在初始化渲染期间，返回的状态 (state) 与传入的第一个参数 (initialState) 值相同
// 你可以在事件处理函数中或其他一些地方调用这个函数。
// 它类似 class 组件的 this.setState，但是它不会把新的 state 和旧的 state 进行合并，而是直接替换

import React, { useState } from "react";

// 每次渲染都是独立的闭包
// 每一次渲染都有它自己的 Props 和 State
// 每一次渲染都有它自己的事件处理函数
// 当点击更新状态的时候，函数组件都会重新被调用，那么每次渲染都是独立的，取到的值不会受后面操作的影响
function Counter2() {
    let [number, setNumber] = useState(0);
    function alertNumber() {
        setTimeout(() => {
            // alert 只能获取到点击按钮时的那个状态
            alert(number);
        }, 3000);
    }
    return (
        <>
            <p>{number}</p>
            <button onClick={() => setNumber(number + 1)}>+</button>
            <button onClick={alertNumber}>alertNumber</button>
        </>
    );
}

function Counter() {
    let [number, setNumber] = useState(0);
    function lazy() {
        setTimeout(() => {
            // setNumber(number+1);
            // 这样每次执行时都会去获取一遍 state，而不是使用点击触发时的那个 state
            setNumber((number) => number + 1);
        }, 3000);
    }
    return (
        <>
            <p>{number}</p>
            <button onClick={() => setNumber(number + 1)}>+</button>
            <button onClick={lazy}>lazy</button>
        </>
    );
}
