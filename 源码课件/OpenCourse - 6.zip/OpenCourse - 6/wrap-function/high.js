function getName(name) {
    return name;
}

function helloWorld(myName) {
    console.log("hello, beautiful world !! my name is " + myName);
}

function byeWorld(myName) {
    console.log("bye, ugly world !! my name is " + myName);
}

function smile(myName) {
    console.log("哈哈哈哈哈啊哈哈" + myName);

}

function wrapWithUserName(wrappedFunc) {
    const tempFunction = () => {
        const myName = getName("qiuku");
        wrappedFunc(myName);
    };
    return tempFunction;
}

wrapWithUserName(helloWorld)();
wrapWithUserName(byeWorld)();
wrapWithUserName(smile)();

// 或者

// export const wrappedHelloWorld = wrapWithUserName(helloWorld);
// export const wrappedByeWorld = wrapWithUserName(byeWorld);