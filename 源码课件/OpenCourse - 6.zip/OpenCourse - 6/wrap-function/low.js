function getName(name) {
    return name;
}

function helloWorld() {
    const myName = getName("qiuku");
    console.log("hello, beautiful world !! my name is " + myName);
}

function byeWorld() {
    const myName = getName("qiuku");
    console.log("bye, ugly world !! my name is " + myName);
}

helloWorld();
byeWorld();