# React.js 高级用法

`npx create-react-app my-app --template typescript`

http://www.chauvet.cc/react/hocInHooks.html
http://huziketang.mangojuice.top/books/react/lesson28

## 一、高阶组件用法及封装

### 什么是高阶组件

高阶组件简称 HOC, 即为 High Order Components.

`A higher-order component is a function that takes a component and returns a new component.`

咱们稍微分解一下官方定义，可以得到以下信息：

1. 高阶组件是一个**函数**
2. 入参：原 react 组件
3. 出参：新 react 组件
4. 高阶组件是一个纯函数, 它不应该有任何副作用, 比如修改传入的 react 组件(当然这个不是上面那句话能看出来的，这一点称之为约束或者规范更合理一些)

所以，高阶组件是一个函数，接收一个组件，返回一个组件。

### 先来写一个高阶函数

在写高阶组件之前, 咱们根据上面的 4 条信息, 先写一个简单的高阶函数的实现试一下。

比如现在有两个函数，

```js
function helloWorld() {
    const myName = sessionStorage.getItem("qiuku");
    console.log("hello, beautiful world !! my name is " + myName);
}

function byeWorld() {
    const myName = sessionStorage.getItem("qiuku");
    console.log("bye, ugly world !! my name is " + myName);
}

helloWorld();
byeWorld();
```

两个函数一个表达了对世界的渴望与好奇, 是一种新生；一个表达了对世界的失望与无奈，是一种死去；文艺的一匹
但是我们可以发现, myName 的获取逻辑都是一样的, 而我们重复写了两遍, 只有 console.log 的逻辑是不同的。
万一以后 myName 的获取逻辑变了怎么办？？我们能不能封装一下？

所以我们可以写一个中间函数, 里面包含获取 myName 的逻辑。

```js
function helloWorld(myName) {
    console.log("hello, beautiful world !! my name is " + myName);
}

function byeWorld(myName) {
    console.log("bye, ugly world !! my name is " + myName);
}

function wrapWithUserName(wrappedFunc) {
    const tempFunction = () => {
        const myName = sessionStorage.getItem("qiuku");
        wrappedFunc(myName);
    };
    return tempFunction;
}

wrapWithUserName(helloWorld)();
wrapWithUserName(byeWorld)();
```

### 怎样写一个高阶组件

平时看到的大概是这样的
`export const NewComponent = hoc(WrappedComponent);`

1. 普通方式

    接下来咱们用普通方式写一个类的高阶组件

2. 装饰器

    接下来咱们用装饰器方式写一个类的高阶组件

3. 多个高阶组件组合

    会发现用普通方式书写的话, 逻辑会显得非常乱, 所以建议使用装饰器的写法。

### 高阶组件能用来做什么

1. 属性代理

    1.1 操作 props 其实上面的这几个例子, 就是在操作 props
    1.2 操作组件实例

2. 继承/劫持

## 二、react hooks

### 什么是 react hooks

Hook 即为"钩子", 是 react 16.8 的新特性, 你可以在不写 class 的情况下使用 state 和其他的 react 特性。

凡是 use 开头的 React API 都是 Hooks.

那么为什么要不写 class 呢？hook 相对于 class 又有什么优势呢？

### react hooks 有什么优势

先来看一下 class 写组件有什么不足之处吧！

1. 组件间的状态逻辑很难复用

组件间如果有 state 的逻辑是类似的话, class 模式下基本都是用高阶组件来解决的,。
虽然能够解决问题, 但是你会发现, 我们可能需要在组件外部再包一层元素, 会导致层级非常冗余

2. 复杂业务的有状态组件会越来越复杂

比如类组件中都是通过更改 this.state 来达到状态修改的目的的, 但是组件内部太多对 state 的访问和修改, 很难在后期给拆成更细粒度的组件, 就会导致组件越来越庞大。
还有比如设置监听, 比如添加定时器, 我们需要在两个生命周期里完成注册和销毁, 很有可能漏写导致内存问题

```js
componentDidMount() {
    const timer = setInterval(() => {});
    this.setState({timer})
}

componentWillUnmount() {
    if (this.state.timer) {
        clearInterval(this.state.timer);
    }
}
```

3. this 指向问题

react 里绑定事件函数有以下四种方法，如果新玩家刚接触，稍不注意就会写错，导致性能上的大大损耗。

```js
class App extends React.Component<any, any> {
    handleClick2;

    constructor(props) {
        super(props);
        this.state = {
            num: 1,
            title: " react study",
        };
        this.handleClick2 = this.handleClick1.bind(this);
    }

    handleClick1() {
        this.setState({
            num: this.state.num + 1,
        });
    }

    handleClick3 = () => {
        this.setState({
            num: this.state.num + 1,
        });
    };

    render() {
        return (
            <div>
                <h2>Ann, {this.state.num}</h2>
                {/* 在render函数里绑定this，由于bind会返回一个新函数, 所以每次父组件刷新都会导致子组件的重新刷新, 就算子组件的其他props没有改变。*/}
                <button onClick={this.handleClick1.bind(this)}>btn1</button>
                {/* 构造函数内绑定this, 每次父组件刷新的时候, 如果传递给子组件的其他props不变, 子组件就不会刷新。*/}
                <button onClick={this.handleClick2}>btn2</button>
                {/* 使用箭头函数, 每次都会生成一个新的箭头函数, 每次父组件刷新的时候, 如果传递给子组件的其他props不变, 子组件就不会刷新*/}
                <button onClick={() => this.handleClick1()}>btn3</button>
                {/* 使用类里定义的箭头函数, 和handleClick2原理一样, 但是比第二种更简洁 */}
                <button onClick={this.handleClick3}>btn4</button>
            </div>
        );
    }
}
```

---

---

---

而 hooks 的优点, 一对比就比较明显了

1. 能优化类组件的三大问题
2. 能在无需修改组件结构的情况下复用状态逻辑（自定义 Hooks ）
3. 能将组件中相互关联的部分拆分成更小的函数（比如设置订阅或请求数据）
4. 副作用的概念

副作用指那些没有发生在数据向视图转换过程中的逻辑，如 ajax 请求、访问原生 dom 元素、本地持久化缓存、绑定/解绑事件、添加订阅、设置定时器、记录日志等。
以往这些副作用都是写在类组件生命周期函数中的。
而 useEffect 在全部渲染完毕后才会执行，useLayoutEffect 会在浏览器 layout 之后，painting 之前执行。
而且比如绑定/解绑事件都可以写在一个副作用函数里了, 不会再散落在各地难以维护。

### react hooks 的注意事项

1. 只能在函数内部的最外层调用 Hook，不要在循环、条件判断或者子函数中调用
2. 只能在 React 的函数组件中调用 Hook，不要在其他 JavaScript 函数中调用

### react hooks 是怎么实现的

https://github.com/brickspert/blog/issues/26

说了这么多, 优点啊, 注意事项啊, 大家可能比较懵逼。

1. 为什么不能在循环或者判断条件中使用？？
2. 为什么 useEffect 的第二个参数是空数组, 就相当于 componentDidMount 只执行一次？？
3. 自定义 hook 怎么操作组件的？

接下来我们来实现一下简单的 Hooks, 一看就懂了。

1. useState

先来看一下 useState 是怎么使用的

`const [count, setCount] = useState(0);`

传入一个初始值, 返回一个状态值和一个设置状态的方法。

咱们先来实现一个简易的 useState。

可以看到这个 useState 只支持设置一次的, 如果是多个 useState 的话就无法满足需求了。

---

---

那么咱们来看看怎么支持多个 useState！！

前面 useState 的简单实现里，初始的状态是保存在一个全局变量中的。
以此类推，多个状态，应该是保存在一个专门的全局容器中。这个容器，就是一个朴实无华的 Array 对象。具体过程如下：

-   第一次渲染时候，根据 useState 顺序，逐个声明 state 并且将其放入全局 Array 中。
-   每次声明 state，都要将 cursor 增加 1。
-   更新 state，触发再次渲染的时候，cursor 被重置为 0。
-   按照 useState 的声明顺序，依次拿出最新的 state 的值，视图更新。

那么明白了原理之后, 你可能也会想明白为什么不能在循环或者判断条件中使用了吧？？

因为是按照数组索引入存储的, 如果在判断中使用, 某个 state 没有按照对应索引存储，那么后面的 state 索引也会有问题。

来看个例子

2. useEffect

来看一下最基本的用法

```js
useEffect(() => {
    console.log(count);
}, [count]);
```

它有如下四个特点

-   有两个参数 callback 和 dependencies 数组
-   如果 dependencies 不存在，那么 callback 每次 render 都会执行
-   如果 dependencies 存在，只有当它发生了变化， callback 才会执行
-   如果 dependencies 为空数组, 则只执行一次 callback

接下来来实现一个简易 useEffect 吧！！

--

--

它同样有个问题, 就是只能注册一个 useEffect，利用相同的 cursor+array 的思想，实现多个 useEffect 的注册吧

### react hooks 用法详解

https://juejin.im/post/5dbbdbd5f265da4d4b5fe57d

1. useState
2. useEffect
3. useMemo
4. useReducer
5. useRef
6. 自定义 hook useInterval
7. 自定义 redux

## 异步组件/suspense 等新版内容介绍

https://juejin.im/post/5c399394e51d4552411ac8a9
