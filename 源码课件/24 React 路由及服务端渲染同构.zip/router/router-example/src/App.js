import React from 'react';
import {Route, Link} from './Router'
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <Link to="/">home</Link>
      #####
      <Link to="/about/test">about/test</Link>
      #####
      <Link to="/about/second">about/second</Link>

      <Route exact strict path="/about" component={About} />
      <Route path="/" render={(props) => <Home />} />
      <Route path="/">
      </Route>
    </div>
  );
}

function About({match}) {
  return (
    <div>about {match.params.id}</div>
  )
}

function Home() {
  return (
    <div>home</div>
  )
}

export default App;
