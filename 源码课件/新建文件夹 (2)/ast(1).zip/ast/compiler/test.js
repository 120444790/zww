const parser = require('./index.js');

const input = "(add 2 (subtract 4 2))"
const output = "add(2,subtract(4,2));"

console.log("input", input);
console.log("output", parser(input));