module.exports = function({types: t}) {
  return {
    visitor: {
      Identifier(path, state) {
        const name = path.node.name;
        if (state.opts[name]) {
          path.node.name = state.opts[name]
        }
      },
      MemberExpression(path) {
        if (path.get("object").matchesPattern("process.env")) {
          const key = path.toComputedKey();
          if (t.isStringLiteral(key)) {
            path.replaceWith(t.valueToNode(process.env[key.value]));
          }
        }
      },
      BinaryExpression(path) {
        console.log(path.node.left);
        console.log(path.node.right);
      }
    }
  }
}