const apiKey = '7f65a98cdbf1496088f8cb61e23fd2e8';
const topHeadlinesUrl =
  'https://newsapi.org/v2/top-headlines?country=us&apiKey=' + apiKey;

export { apiKey, topHeadlinesUrl };
