export function getNewsByChannel(channel, start = 0, end = 18) {
  return new Promise((resolve, reject) => {
    const api = `http://is.snssdk.com/api/news/feed/v51/?category=${channel}`;
    fetch(api)
      .then(resp => resp.json())
      .then(json => {
        if (json.message === 'success') {
          const newsArr = json.data;
          let list = [];
          for (let item of newsArr) {
            const content = item.content;
            const json = JSON.parse(content);
            list.push(json);
          }
          resolve(list);
        } else {
          throw new Error(json.status);
        }
      })
      .catch(e => {
        reject(e.toString());
      });
  })
}