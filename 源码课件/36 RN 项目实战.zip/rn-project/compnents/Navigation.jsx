import React, { useLayoutEffect } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import NewsScreen from './NewsScreen';
import FindScreen from './FindScreen';

const Tab = createBottomTabNavigator();
const INIT_ROUTE_NAME = 'News';

function getTitleFromRoute(route) {
  const routeName = route.state?.routes[route.state.index]?.name ?? INIT_ROUTE_NAME;
  if (routeName === 'News') return "新闻";
  if (routeName === 'Find') return "发现";
}

export default function({navigation, route}) {
  useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: getTitleFromRoute(route),
    });
  }, [route]);

  return (
    <Tab.Navigator>
      <Tab.Screen
        name="News"
        options={{
          title: "新闻",
          tabBarIcon: ({focused}) => {
            return null;
          }
        }}
        component={NewsScreen}
      />
      <Tab.Screen
        name="Find"
        options={{
          title: "发现",
          tabBarIcon: ({focused}) => {
            return null;
          }
        }}
        component={FindScreen}
      />
    </Tab.Navigator>
  );
}