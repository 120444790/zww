import React from 'react';
import {Text} from 'react-native';
import NewsList from './NewsList';

export default function() {
  return <NewsList />
}