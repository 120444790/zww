import React, { useEffect, useState, useCallback } from 'react';
import * as WebBrowser from "expo-web-browser";
import {FlatList, Text, View, StyleSheet, TouchableOpacity} from 'react-native'
import styled from 'styled-components/native';
import {getNewsByChannel} from '../api/news';

const Container = styled.View`
  padding: 24px;
`;
const Title = styled.Text`
  font-size: 16px;
  font-weight: 500;
  color: #000;
`;

const Abstract = styled.Text`
  font-size: 12px;
  color: grey;
  padding-top: 5px;
`

const Loading = styled.Text`
  flex-direction: row;
  justify-content: center;
  width: 100%;
  text-align: center;
`

const Line = styled.View`
  height: 1px;
  background-color: #666;
  margin: 4px 0;
`

export default function() {
  const [content, setContent] = useState([]);
  const [page, setPage] = useState(0);

  useEffect(() => {
    async function fetchNews() {
      const content = await getNewsByChannel(null, page);
      setContent(prev => prev.concat(content));
    }
    fetchNews();
  }, [setContent, page]);

  const loadMore = useCallback(() => {
    setPage(page => page + 1);
  }, [setPage]);

  return (
    <FlatList
      data={content}
      ItemSeparatorComponent={() => {
        return (<Line />)
      }}
      keyExtractor={(item, index) => index.toString()}
      onEndReached={loadMore}
      onEndReachedThreshold={0.2}
      ListFooterComponent={() => <Loading>loading...</Loading>}
      renderItem={({item}) => {
        return (
          <TouchableOpacity onPress={() => WebBrowser.openBrowserAsync(item.url)}>
            <Container>
              <Title>{item.title}</Title>
              <Abstract>{item.abstract}</Abstract>
            </Container>
          </TouchableOpacity>
        )
      }}
    >
    </FlatList>
  )
}