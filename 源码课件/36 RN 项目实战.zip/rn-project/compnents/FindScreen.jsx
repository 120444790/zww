import React from 'react';
import {Text} from 'react-native';
export default function() {
  return <Text>发现</Text>
}