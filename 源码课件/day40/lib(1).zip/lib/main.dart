import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutterDemo2/MainEntry.dart';

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MainEntry(),
    );
  }
}

void main() {
// 如何在flutter中捕捉错误
  final isProd = const bool.fromEnvironment('dart.vm.product');

  if (isProd) {
    runZoned(() => runApp(App()), onError: (Object obj, StackTrace stack) {
      print(obj.toString());
      print(stack.toString());
    });
  } else {
    runApp(App());
  }
}
