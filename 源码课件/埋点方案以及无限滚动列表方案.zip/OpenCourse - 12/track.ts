/* eslint-disable no-console */
import queryString from 'query-string';
import { v4 as uuid } from 'uuid';

let image: HTMLImageElement | null;

type Params = { [key: string]: any };

interface StorageType {
    eventId: string;
    data: Params;
}

class TrackStorage {
    private static readonly STORAGE_KEY: string  = 'qiuku_track';

    public static addStorageEvent(eventId: string, data: Params) {
        const existEvents = this.getStorageEvents();
        this.setStorage(JSON.stringify(existEvents.push({eventId, data})));
    }

    public static getStorageEvents() {
        const storage = localStorage.getItem(this.STORAGE_KEY);
        return (storage ? JSON.parse(storage) : []) as StorageType[];
    }

    public static removeStorageEvent(eventId: string) {
        const existEvents = this.getStorageEvents();
        this.setStorage(JSON.stringify(existEvents.filter(item => item.eventId !== eventId)));
    }

    public static getTraceId() {
        try {
            const traceKey = 'qiuku_track_id';
            let traceId = localStorage.getItem(traceKey);
            if (!traceId) {
                traceId = uuid();
                localStorage.setItem(traceKey, traceId!);
            }
            return traceId;
        } catch (e) {
            return '';
        }
    }

    private static setStorage(value: string) {
        localStorage.setItem(this.STORAGE_KEY, value);
    }
}

export class BaseTrack {

    public static init() {
        if (window.addEventListener) {
            window.addEventListener('beforeunload', this.reportAllStorageEvent, false)
        } else if ((window as any).attachEvent) {
            (window as any).attachEvent('onbeforeunload', this.reportAllStorageEvent)
        }
    }

    public static track(eventId: string, params: Params, store: boolean = true) {
        try {
            const qs = queryString.stringify({
                timestamp: Date.now(),
                traceId: TrackStorage.getTraceId(),
                url: location.href,
                userId: this.getCookie('userId'),
                ...params,
            });
            if (store) {
                const uniqueEventId = `${uuid()}_${eventId}`;
                // 加uuid, 因为可能有多次同eventId的上报
                TrackStorage.addStorageEvent(uniqueEventId, params);
                this.reportByImg(uniqueEventId, qs);
            } else {
                this.reportByImg(eventId, qs);
            }
        } catch (e) {
            console.error(e);
        }
    }

    private static serverUrl: string =
        'https://open-demo-qiuku.cn-beijing.log.aliyuncs.com/logstores/qiuku-demo/track_ua.gif?APIVersion=0.6.0&';

    private static reportByImg(uniqueEventId: string, qs: string, retryTimes: number = 3) {
        const eventId = uniqueEventId.split('_')[0];
        const retry = () => {
            image = null;
            retryTimes && this.reportByImg(eventId, qs, retryTimes - 1);
        };
        return new Promise((resolve) => {
            try { 
                image = new Image();
                image.onload = () => {
                    TrackStorage.removeStorageEvent(eventId);
                };
                image.onerror = () => {
                    retry();
                };
                image.src = this.serverUrl + qs;
            } catch (e) {
                console.error(e);
            }
        });
    }

    private static getCookie(key: string) {
        if (document) {
          const list = document.cookie.match(new RegExp('(?:^| )' + encodeURIComponent(key) + '=([^;]+)'))
          return list && decodeURIComponent(list[1])
        } else {
          return ''
        }
    }

    private static reportAllStorageEvent() {
        const storageEvents = TrackStorage.getStorageEvents();
        storageEvents.forEach(item => {
            this.track(item.eventId, item.data, false);
        })
    }
}
