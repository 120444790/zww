import { observable, action, decorate } from 'mobx'

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

class Todo {
  id = Math.random();

  text = ""
}

class Todos {
  // @observable
  data = [];

  // @action
  async addTodo(text) {
    await sleep(1000)
    const todo = new Todo()
    todo.text = text
    this.data.push(todo)
  }
}

decorate(Todos, {
  data: observable,
  addTodo: action
})

export default Todos