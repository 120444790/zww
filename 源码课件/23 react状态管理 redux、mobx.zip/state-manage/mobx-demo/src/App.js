import React from 'react';
import logo from './logo.svg';
import './App.css';
import Todos from './mobx/todo'
import TodoApp from './components/TodoApp'

const todos = new Todos()

function App() {
  return (
    <TodoApp todos={todos} />
  );
}

export default App;
