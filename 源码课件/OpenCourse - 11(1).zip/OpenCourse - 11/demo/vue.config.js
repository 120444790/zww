module.exports = {
    configureWebpack: config => {
        if (process.env.npm_lifecycle_event === 'analysis') {
            const {
                BundleAnalyzerPlugin
            } = require('webpack-bundle-analyzer');
            config.plugins.push(
                new BundleAnalyzerPlugin({
                    generateStatsFile: true,
                    statsOptions: {
                        source: false
                    }
                })
            );
        }
    }
}