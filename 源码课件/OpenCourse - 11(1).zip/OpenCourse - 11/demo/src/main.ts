// import '@babel/polyfill';

import Vue from 'vue';
import App from './App.vue';
import './registerServiceWorker';
import router from './router';
import { Performance } from '../src/utils/performance';

Vue.config.productionTip = false;

Performance.init();

Vue.directive('analysis', {
    inserted(el, options) {
        console.log(`${options.value} = ${Date.now() - window.performance.timing.navigationStart}`);
    }
});

new Vue({
  router,
  render: (h) => h(App),
  mixins: [Performance.record(router)],
}).$mount('#app');
