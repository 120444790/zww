<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" v-analysis="'whiteScreen'">
    <HelloWorld msg="Welcome to Your Vue.js + TypeScript App" />
    <HelloWorld msg="Welcome to Your Vue.js + TypeScript App" />


    <HelloWorld msg="Welcome to Your Vue.js + TypeScript App" v-analysis="'firstScreen'" v-if="!loading"/>

  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import HelloWorld from '@/components/HelloWorld.vue'; // @ is an alias to /src

@Component({
  components: {
    HelloWorld,
  },
})
export default class Home extends Vue {
    loading: boolean = true;

    created() {
        setTimeout(() => {
            this.loading =false;
        }, 1000)
    }
}
</script>
