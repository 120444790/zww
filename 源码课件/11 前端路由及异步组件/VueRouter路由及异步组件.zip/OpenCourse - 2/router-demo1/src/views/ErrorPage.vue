<template>
    <div class="home">
        404
    </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
    components: {}
})
export default class ErrorPage extends Vue {}
</script>
